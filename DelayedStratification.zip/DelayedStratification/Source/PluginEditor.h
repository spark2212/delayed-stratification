/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class DelayedStratificationAudioProcessorEditor  : public juce::AudioProcessorEditor
{
public:
    DelayedStratificationAudioProcessorEditor (DelayedStratificationAudioProcessor&);
    ~DelayedStratificationAudioProcessorEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    DelayedStratificationAudioProcessor& audioProcessor;
    
    juce::Slider delaySlider1;
    juce::Label delayLabel1;
    juce::ComboBox unitsMenu1;
    juce::Label unitsLabel1;
    juce::Slider decayKnob1;
    juce::Label decayLabel1;
    juce::Slider gainKnob1;
    juce::Label gainLabel1;
    juce::Slider panKnob1;
    juce::Label panLabel1;
    
    juce::Slider delaySlider2;
    juce::Label delayLabel2;
    juce::ComboBox unitsMenu2;
    juce::Label unitsLabel2;
    juce::Slider decayKnob2;
    juce::Label decayLabel2;
    juce::Slider gainKnob2;
    juce::Label gainLabel2;
    juce::Slider panKnob2;
    juce::Label panLabel2;
    
    juce::Slider delaySlider3;
    juce::Label delayLabel3;
    juce::ComboBox unitsMenu3;
    juce::Label unitsLabel3;
    juce::Slider decayKnob3;
    juce::Label decayLabel3;
    juce::Slider gainKnob3;
    juce::Label gainLabel3;
    juce::Slider panKnob3;
    juce::Label panLabel3;
    
    juce::Slider delaySlider4;
    juce::Label delayLabel4;
    juce::ComboBox unitsMenu4;
    juce::Label unitsLabel4;
    juce::Slider decayKnob4;
    juce::Label decayLabel4;
    juce::Slider gainKnob4;
    juce::Label gainLabel4;
    juce::Slider panKnob4;
    juce::Label panLabel4;
    
    juce::Slider delaySlider5;
    juce::Label delayLabel5;
    juce::ComboBox unitsMenu5;
    juce::Label unitsLabel5;
    juce::Slider decayKnob5;
    juce::Label decayLabel5;
    juce::Slider gainKnob5;
    juce::Label gainLabel5;
    juce::Slider panKnob5;
    juce::Label panLabel5;
    
    juce::Slider delaySlider6;
    juce::Label delayLabel6;
    juce::ComboBox unitsMenu6;
    juce::Label unitsLabel6;
    juce::Slider decayKnob6;
    juce::Label decayLabel6;
    juce::Slider gainKnob6;
    juce::Label gainLabel6;
    juce::Slider panKnob6;
    juce::Label panLabel6;
    
    juce::Slider delaySlider7;
    juce::Label delayLabel7;
    juce::ComboBox unitsMenu7;
    juce::Label unitsLabel7;
    juce::Slider decayKnob7;
    juce::Label decayLabel7;
    juce::Slider gainKnob7;
    juce::Label gainLabel7;
    juce::Slider panKnob7;
    juce::Label panLabel7;
    
    juce::Slider delaySlider8;
    juce::Label delayLabel8;
    juce::ComboBox unitsMenu8;
    juce::Label unitsLabel8;
    juce::Slider decayKnob8;
    juce::Label decayLabel8;
    juce::Slider gainKnob8;
    juce::Label gainLabel8;
    juce::Slider panKnob8;
    juce::Label panLabel8;
    
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayAttachment1;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> unitsAttachment1;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> decayAttachment1;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment1;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAttachment1;
    
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayAttachment2;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> unitsAttachment2;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> decayAttachment2;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment2;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAttachment2;
    
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayAttachment3;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> unitsAttachment3;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> decayAttachment3;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment3;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAttachment3;
    
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayAttachment4;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> unitsAttachment4;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> decayAttachment4;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment4;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAttachment4;

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayAttachment5;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> unitsAttachment5;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> decayAttachment5;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment5;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAttachment5;
    
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayAttachment6;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> unitsAttachment6;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> decayAttachment6;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment6;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAttachment6;
    
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayAttachment7;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> unitsAttachment7;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> decayAttachment7;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment7;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAttachment7;
    
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayAttachment8;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> unitsAttachment8;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> decayAttachment8;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment8;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAttachment8;
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DelayedStratificationAudioProcessorEditor)
};
