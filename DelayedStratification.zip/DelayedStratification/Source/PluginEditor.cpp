/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
DelayedStratificationAudioProcessorEditor::DelayedStratificationAudioProcessorEditor (DelayedStratificationAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    DBG("Editor constructor");
    
    setSize (1200, 700);
    
    delaySlider1.setSliderStyle(juce::Slider::LinearHorizontal);
    delaySlider1.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 20);
    
    delayAttachment1.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDELAY1, delaySlider1));
    
    addAndMakeVisible(&delaySlider1);
    
    delayLabel1.setText("Delay", juce::dontSendNotification);
    addAndMakeVisible(&delayLabel1);
    
    unitsMenu1.addItem("0.01 seconds", 1);
    unitsMenu1.addItem("seconds", 2);
    
    unitsAttachment1.reset(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(audioProcessor.apvts, JUCEPARAMUNITS1, unitsMenu1));   // reset ComboBoxAttachment
    
    addAndMakeVisible(&unitsMenu1);
    
    unitsLabel1.setText("Units", juce::dontSendNotification);
    addAndMakeVisible(&unitsLabel1);
    
    decayKnob1.setSliderStyle(juce::Slider::Rotary);
    decayKnob1.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&decayKnob1);
    
    decayAttachment1.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDECAY1, decayKnob1));
    
    decayLabel1.setText("Decay", juce::dontSendNotification);
    addAndMakeVisible(&decayLabel1);
    
    gainKnob1.setSliderStyle(juce::Slider::Rotary);
    gainKnob1.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&gainKnob1);
    
    gainAttachment1.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMGAIN1, gainKnob1));
    
    gainLabel1.setText("Gain", juce::dontSendNotification);
    addAndMakeVisible(&gainLabel1);
    
    panKnob1.setSliderStyle(juce::Slider::Rotary);
    panKnob1.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&panKnob1);
    
    panAttachment1.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMPAN1, panKnob1));
    
    panLabel1.setText("Pan", juce::dontSendNotification);
    addAndMakeVisible(&panLabel1);
    
    
    delaySlider2.setSliderStyle(juce::Slider::LinearHorizontal);
    delaySlider2.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 20);
    
    delayAttachment2.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDELAY2, delaySlider2));
    
    addAndMakeVisible(&delaySlider2);
    
    delayLabel2.setText("Delay", juce::dontSendNotification);
    addAndMakeVisible(&delayLabel2);
    
    unitsMenu2.addItem("0.01 seconds", 1);
    unitsMenu2.addItem("seconds", 2);
    
    unitsAttachment2.reset(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(audioProcessor.apvts, JUCEPARAMUNITS2, unitsMenu2));   // reset ComboBoxAttachment
    
    addAndMakeVisible(&unitsMenu2);
    
    unitsLabel2.setText("Units", juce::dontSendNotification);
    addAndMakeVisible(&unitsLabel2);
    
    decayKnob2.setSliderStyle(juce::Slider::Rotary);
    decayKnob2.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&decayKnob2);
    
    decayAttachment2.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDECAY2, decayKnob2));
    
    decayLabel2.setText("Decay", juce::dontSendNotification);
    addAndMakeVisible(&decayLabel2);
    
    gainKnob2.setSliderStyle(juce::Slider::Rotary);
    gainKnob2.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&gainKnob2);
    
    gainAttachment2.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMGAIN2, gainKnob2));
    
    gainLabel2.setText("Gain", juce::dontSendNotification);
    addAndMakeVisible(&gainLabel2);
    
    panKnob2.setSliderStyle(juce::Slider::Rotary);
    panKnob2.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&panKnob2);
    
    panAttachment2.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMPAN2, panKnob2));
    
    panLabel2.setText("Pan", juce::dontSendNotification);
    addAndMakeVisible(&panLabel2);
    
    
    delaySlider3.setSliderStyle(juce::Slider::LinearHorizontal);
    delaySlider3.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 20);
    
    delayAttachment3.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDELAY3, delaySlider3));
    
    addAndMakeVisible(&delaySlider3);
    
    delayLabel3.setText("Delay", juce::dontSendNotification);
    addAndMakeVisible(&delayLabel3);
    
    unitsMenu3.addItem("0.01 seconds", 1);
    unitsMenu3.addItem("seconds", 2);
    
    unitsAttachment3.reset(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(audioProcessor.apvts, JUCEPARAMUNITS3, unitsMenu3));   // reset ComboBoxAttachment
    
    addAndMakeVisible(&unitsMenu3);
    
    unitsLabel3.setText("Units", juce::dontSendNotification);
    addAndMakeVisible(&unitsLabel3);
    
    decayKnob3.setSliderStyle(juce::Slider::Rotary);
    decayKnob3.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&decayKnob3);
    
    decayAttachment3.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDECAY3, decayKnob3));
    
    decayLabel3.setText("Decay", juce::dontSendNotification);
    addAndMakeVisible(&decayLabel3);
    
    gainKnob3.setSliderStyle(juce::Slider::Rotary);
    gainKnob3.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&gainKnob3);
    
    gainAttachment3.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMGAIN3, gainKnob3));
    
    gainLabel3.setText("Gain", juce::dontSendNotification);
    addAndMakeVisible(&gainLabel3);
    
    panKnob3.setSliderStyle(juce::Slider::Rotary);
    panKnob3.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&panKnob3);
    
    panAttachment3.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMPAN3, panKnob3));
    
    panLabel3.setText("Pan", juce::dontSendNotification);
    addAndMakeVisible(&panLabel3);
    
    
    delaySlider4.setSliderStyle(juce::Slider::LinearHorizontal);
    delaySlider4.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 20);
    
    delayAttachment4.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDELAY4, delaySlider4));
    
    addAndMakeVisible(&delaySlider4);
    
    delayLabel4.setText("Delay", juce::dontSendNotification);
    addAndMakeVisible(&delayLabel4);
    
    unitsMenu4.addItem("0.01 seconds", 1);
    unitsMenu4.addItem("seconds", 2);
    
    unitsAttachment4.reset(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(audioProcessor.apvts, JUCEPARAMUNITS4, unitsMenu4));   // reset ComboBoxAttachment
    
    addAndMakeVisible(&unitsMenu4);
    
    unitsLabel4.setText("Units", juce::dontSendNotification);
    addAndMakeVisible(&unitsLabel4);
    
    decayKnob4.setSliderStyle(juce::Slider::Rotary);
    decayKnob4.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&decayKnob4);
    
    decayAttachment4.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDECAY4, decayKnob4));
    
    decayLabel4.setText("Decay", juce::dontSendNotification);
    addAndMakeVisible(&decayLabel4);
    
    gainKnob4.setSliderStyle(juce::Slider::Rotary);
    gainKnob4.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&gainKnob4);
    
    gainAttachment4.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMGAIN4, gainKnob4));
    
    gainLabel4.setText("Gain", juce::dontSendNotification);
    addAndMakeVisible(&gainLabel4);
    
    panKnob4.setSliderStyle(juce::Slider::Rotary);
    panKnob4.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&panKnob4);
    
    panAttachment4.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMPAN4, panKnob4));
    
    panLabel4.setText("Pan", juce::dontSendNotification);
    addAndMakeVisible(&panLabel4);
    
    
    delaySlider5.setSliderStyle(juce::Slider::LinearHorizontal);
    delaySlider5.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 20);
    
    delayAttachment5.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDELAY5, delaySlider5));
    
    addAndMakeVisible(&delaySlider5);
    
    delayLabel5.setText("Delay", juce::dontSendNotification);
    addAndMakeVisible(&delayLabel5);
    
    unitsMenu5.addItem("0.01 seconds", 1);
    unitsMenu5.addItem("seconds", 2);
    
    unitsAttachment5.reset(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(audioProcessor.apvts, JUCEPARAMUNITS5, unitsMenu5));   // reset ComboBoxAttachment
    
    addAndMakeVisible(&unitsMenu5);
    
    unitsLabel5.setText("Units", juce::dontSendNotification);
    addAndMakeVisible(&unitsLabel5);
    
    decayKnob5.setSliderStyle(juce::Slider::Rotary);
    decayKnob5.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&decayKnob5);
    
    decayAttachment5.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDECAY5, decayKnob5));
    
    decayLabel5.setText("Decay", juce::dontSendNotification);
    addAndMakeVisible(&decayLabel5);
    
    gainKnob5.setSliderStyle(juce::Slider::Rotary);
    gainKnob5.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&gainKnob5);
    
    gainAttachment5.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMGAIN5, gainKnob5));
    
    gainLabel5.setText("Gain", juce::dontSendNotification);
    addAndMakeVisible(&gainLabel5);
    
    panKnob5.setSliderStyle(juce::Slider::Rotary);
    panKnob5.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&panKnob5);
    
    panAttachment5.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMPAN5, panKnob5));
    
    panLabel5.setText("Pan", juce::dontSendNotification);
    addAndMakeVisible(&panLabel5);
    
    
    delaySlider6.setSliderStyle(juce::Slider::LinearHorizontal);
    delaySlider6.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 20);
    
    delayAttachment6.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDELAY6, delaySlider6));
    
    addAndMakeVisible(&delaySlider6);
    
    delayLabel6.setText("Delay", juce::dontSendNotification);
    addAndMakeVisible(&delayLabel6);
    
    unitsMenu6.addItem("0.01 seconds", 1);
    unitsMenu6.addItem("seconds", 2);
    
    unitsAttachment6.reset(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(audioProcessor.apvts, JUCEPARAMUNITS6, unitsMenu6));   // reset ComboBoxAttachment
    
    addAndMakeVisible(&unitsMenu6);
    
    unitsLabel6.setText("Units", juce::dontSendNotification);
    addAndMakeVisible(&unitsLabel6);
    
    decayKnob6.setSliderStyle(juce::Slider::Rotary);
    decayKnob6.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&decayKnob6);
    
    decayAttachment6.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDECAY6, decayKnob6));
    
    decayLabel6.setText("Decay", juce::dontSendNotification);
    addAndMakeVisible(&decayLabel6);
    
    gainKnob6.setSliderStyle(juce::Slider::Rotary);
    gainKnob6.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&gainKnob6);
    
    gainAttachment6.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMGAIN6, gainKnob6));
    
    gainLabel6.setText("Gain", juce::dontSendNotification);
    addAndMakeVisible(&gainLabel6);
    
    panKnob6.setSliderStyle(juce::Slider::Rotary);
    panKnob6.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&panKnob6);
    
    panAttachment6.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMPAN6, panKnob6));
    
    panLabel6.setText("Pan", juce::dontSendNotification);
    addAndMakeVisible(&panLabel6);
    
    
    delaySlider7.setSliderStyle(juce::Slider::LinearHorizontal);
    delaySlider7.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 20);
    
    delayAttachment7.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDELAY7, delaySlider7));
    
    addAndMakeVisible(&delaySlider7);
    
    delayLabel7.setText("Delay", juce::dontSendNotification);
    addAndMakeVisible(&delayLabel7);
    
    unitsMenu7.addItem("0.01 seconds", 1);
    unitsMenu7.addItem("seconds", 2);
    
    unitsAttachment7.reset(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(audioProcessor.apvts, JUCEPARAMUNITS7, unitsMenu7));   // reset ComboBoxAttachment
    
    addAndMakeVisible(&unitsMenu7);
    
    unitsLabel7.setText("Units", juce::dontSendNotification);
    addAndMakeVisible(&unitsLabel7);
    
    decayKnob7.setSliderStyle(juce::Slider::Rotary);
    decayKnob7.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&decayKnob7);
    
    decayAttachment7.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDECAY7, decayKnob7));
    
    decayLabel7.setText("Decay", juce::dontSendNotification);
    addAndMakeVisible(&decayLabel7);
    
    gainKnob7.setSliderStyle(juce::Slider::Rotary);
    gainKnob7.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&gainKnob7);
    
    gainAttachment7.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMGAIN7, gainKnob7));
    
    gainLabel7.setText("Gain", juce::dontSendNotification);
    addAndMakeVisible(&gainLabel7);
    
    panKnob7.setSliderStyle(juce::Slider::Rotary);
    panKnob7.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&panKnob7);
    
    panAttachment7.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMPAN7, panKnob7));
    
    panLabel7.setText("Pan", juce::dontSendNotification);
    addAndMakeVisible(&panLabel7);
    
    
    delaySlider8.setSliderStyle(juce::Slider::LinearHorizontal);
    delaySlider8.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 20);
    
    delayAttachment8.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDELAY8, delaySlider8));
    
    addAndMakeVisible(&delaySlider8);
    
    delayLabel8.setText("Delay", juce::dontSendNotification);
    addAndMakeVisible(&delayLabel8);
    
    unitsMenu8.addItem("0.01 seconds", 1);
    unitsMenu8.addItem("seconds", 2);
    
    unitsAttachment8.reset(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(audioProcessor.apvts, JUCEPARAMUNITS8, unitsMenu8));   // reset ComboBoxAttachment
    
    addAndMakeVisible(&unitsMenu8);
    
    unitsLabel8.setText("Units", juce::dontSendNotification);
    addAndMakeVisible(&unitsLabel8);
    
    decayKnob8.setSliderStyle(juce::Slider::Rotary);
    decayKnob8.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&decayKnob8);
    
    decayAttachment8.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMDECAY8, decayKnob8));
    
    decayLabel8.setText("Decay", juce::dontSendNotification);
    addAndMakeVisible(&decayLabel8);
    
    gainKnob8.setSliderStyle(juce::Slider::Rotary);
    gainKnob8.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&gainKnob8);
    
    gainAttachment8.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMGAIN8, gainKnob8));
    
    gainLabel8.setText("Gain", juce::dontSendNotification);
    addAndMakeVisible(&gainLabel8);
    
    panKnob8.setSliderStyle(juce::Slider::Rotary);
    panKnob8.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 12);
    
    addAndMakeVisible(&panKnob8);
    
    panAttachment8.reset(new juce::AudioProcessorValueTreeState::SliderAttachment(audioProcessor.apvts, JUCEPARAMPAN8, panKnob8));
    
    panLabel8.setText("Pan", juce::dontSendNotification);
    addAndMakeVisible(&panLabel8);
}

DelayedStratificationAudioProcessorEditor::~DelayedStratificationAudioProcessorEditor()
{
    DBG("editor destructor");
    
    delayAttachment1 = nullptr;
    unitsAttachment1 = nullptr;
    decayAttachment1 = nullptr;
    gainAttachment1 = nullptr;
    panAttachment1 = nullptr;
    
    delayAttachment2 = nullptr;
    unitsAttachment2 = nullptr;
    decayAttachment2 = nullptr;
    gainAttachment2 = nullptr;
    panAttachment2 = nullptr;
    
    delayAttachment3 = nullptr;
    unitsAttachment3 = nullptr;
    decayAttachment3 = nullptr;
    gainAttachment3 = nullptr;
    panAttachment3 = nullptr;
    
    delayAttachment4 = nullptr;
    unitsAttachment4 = nullptr;
    decayAttachment4 = nullptr;
    gainAttachment4 = nullptr;
    panAttachment4 = nullptr;
    
    delayAttachment5 = nullptr;
    unitsAttachment5 = nullptr;
    decayAttachment5 = nullptr;
    gainAttachment5 = nullptr;
    panAttachment5 = nullptr;
    
    delayAttachment6 = nullptr;
    unitsAttachment6 = nullptr;
    decayAttachment6 = nullptr;
    gainAttachment6 = nullptr;
    panAttachment6 = nullptr;
    
    delayAttachment7 = nullptr;
    unitsAttachment7 = nullptr;
    decayAttachment7 = nullptr;
    gainAttachment7 = nullptr;
    panAttachment7 = nullptr;
    
    delayAttachment8 = nullptr;
    unitsAttachment8 = nullptr;
    decayAttachment8 = nullptr;
    gainAttachment8 = nullptr;
    panAttachment8 = nullptr;
}

//==============================================================================
void DelayedStratificationAudioProcessorEditor::paint (juce::Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    auto height = getHeight();
    auto width = getWidth();
    auto area = getLocalBounds();
    
    auto section1 = area.removeFromTop(height * 0.125);
    auto section2 = area.removeFromTop(height * 0.125);
    auto section3 = area.removeFromTop(height * 0.125);
    auto section4 = area.removeFromTop(height * 0.125);
    auto section5 = area.removeFromTop(height * 0.125);
    auto section6 = area.removeFromTop(height * 0.125);
    auto section7 = area.removeFromTop(height * 0.125);
    auto section8 = area;
    
    g.setColour(juce::Colours::darkred);
    g.fillRect(section1);
    
    g.setColour(juce::Colours::darkorange);
    g.fillRect(section2);
    
    g.setColour(juce::Colours::gold);
    g.fillRect(section3);
    
    g.setColour(juce::Colours::darkgreen);
    g.fillRect(section4);
    
    g.setColour(juce::Colours::darkblue);
    g.fillRect(section5);
    
    g.setColour(juce::Colours::indigo);
    g.fillRect(section6);
    
    g.setColour(juce::Colours::violet);
    g.fillRect(section7);
    
    g.setColour(juce::Colours::darkgrey);
    g.fillRect(section8);
    
    /*
    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));

    g.setColour (juce::Colours::white);
    g.setFont (15.0f);
    g.drawFittedText ("Hello World!", getLocalBounds(), juce::Justification::centred, 1);*/
}

void DelayedStratificationAudioProcessorEditor::resized()
{
    auto height = getHeight();
    auto width = getWidth();
    
    //DBG("height == " << height << "\nwidth == " << width);
    
    auto area = getLocalBounds();
    
    auto section1 = area.removeFromTop(height * 0.125);
    section1 = section1.reduced(2);
    auto delay1 = section1.removeFromLeft(width * 0.66);
    auto delayLabelArea1 = delay1.removeFromTop(delay1.getHeight() * 0.20);
    auto units1 = section1.removeFromLeft(section1.getWidth() * 0.33);
    auto unitsLabelArea1 = units1.removeFromTop(units1.getHeight() * 0.20);
    auto decay1 = section1.removeFromLeft(section1.getWidth() * 0.33);
    auto decayLabelArea1 = decay1.removeFromTop(decay1.getHeight() * 0.20);
    auto gain1 = section1.removeFromLeft(section1.getWidth() * 0.5);
    auto gainLabelArea1 = gain1.removeFromTop(gain1.getHeight() * 0.20);
    auto pan1 = section1;
    auto panLabelArea1 = pan1.removeFromTop(pan1.getHeight() * 0.20);
    
    auto section2 = area.removeFromTop(height * 0.125);
    section2 = section2.reduced(2);
    auto delay2 = section2.removeFromLeft(width * 0.66);
    auto delayLabelArea2 = delay2.removeFromTop(delay2.getHeight() * 0.20);
    auto units2 = section2.removeFromLeft(section2.getWidth() * 0.33);
    auto unitsLabelArea2 = units2.removeFromTop(units2.getHeight() * 0.20);
    auto decay2 = section2.removeFromLeft(section2.getWidth() * 0.33);
    auto decayLabelArea2 = decay2.removeFromTop(decay2.getHeight() * 0.20);
    auto gain2 = section2.removeFromLeft(section2.getWidth() * 0.5);
    auto gainLabelArea2 = gain2.removeFromTop(gain2.getHeight() * 0.20);
    auto pan2 = section2;
    auto panLabelArea2 = pan2.removeFromTop(pan2.getHeight() * 0.20);
    
    auto section3 = area.removeFromTop(height * 0.125);
    section3 = section3.reduced(2);
    auto delay3 = section3.removeFromLeft(width * 0.66);
    auto delayLabelArea3 = delay3.removeFromTop(delay3.getHeight() * 0.20);
    auto units3 = section3.removeFromLeft(section3.getWidth() * 0.33);
    auto unitsLabelArea3 = units3.removeFromTop(units3.getHeight() * 0.20);
    auto decay3 = section3.removeFromLeft(section3.getWidth() * 0.33);
    auto decayLabelArea3 = decay3.removeFromTop(decay3.getHeight() * 0.20);
    auto gain3 = section3.removeFromLeft(section3.getWidth() * 0.5);
    auto gainLabelArea3 = gain3.removeFromTop(gain3.getHeight() * 0.20);
    auto pan3 = section3;
    auto panLabelArea3 = pan3.removeFromTop(pan3.getHeight() * 0.20);
    
    auto section4 = area.removeFromTop(height * 0.125);
    section4 = section4.reduced(2);
    auto delay4 = section4.removeFromLeft(width * 0.66);
    auto delayLabelArea4 = delay4.removeFromTop(delay4.getHeight() * 0.20);
    auto units4 = section4.removeFromLeft(section4.getWidth() * 0.33);
    auto unitsLabelArea4 = units4.removeFromTop(units4.getHeight() * 0.20);
    auto decay4 = section4.removeFromLeft(section4.getWidth() * 0.33);
    auto decayLabelArea4 = decay4.removeFromTop(decay4.getHeight() * 0.20);
    auto gain4 = section4.removeFromLeft(section4.getWidth() * 0.5);
    auto gainLabelArea4 = gain4.removeFromTop(gain4.getHeight() * 0.20);
    auto pan4 = section4;
    auto panLabelArea4 = pan4.removeFromTop(pan4.getHeight() * 0.20);
    
    auto section5 = area.removeFromTop(height * 0.125);
    section5 = section5.reduced(2);
    auto delay5 = section5.removeFromLeft(width * 0.66);
    auto delayLabelArea5 = delay5.removeFromTop(delay5.getHeight() * 0.20);
    auto units5 = section5.removeFromLeft(section5.getWidth() * 0.33);
    auto unitsLabelArea5 = units5.removeFromTop(units5.getHeight() * 0.20);
    auto decay5 = section5.removeFromLeft(section5.getWidth() * 0.33);
    auto decayLabelArea5 = decay5.removeFromTop(decay5.getHeight() * 0.20);
    auto gain5 = section5.removeFromLeft(section5.getWidth() * 0.5);
    auto gainLabelArea5 = gain5.removeFromTop(gain5.getHeight() * 0.20);
    auto pan5 = section5;
    auto panLabelArea5 = pan5.removeFromTop(pan5.getHeight() * 0.20);
    
    auto section6 = area.removeFromTop(height * 0.125);
    section6 = section6.reduced(2);
    auto delay6 = section6.removeFromLeft(width * 0.66);
    auto delayLabelArea6 = delay6.removeFromTop(delay6.getHeight() * 0.20);
    auto units6 = section6.removeFromLeft(section6.getWidth() * 0.33);
    auto unitsLabelArea6 = units6.removeFromTop(units6.getHeight() * 0.20);
    auto decay6 = section6.removeFromLeft(section6.getWidth() * 0.33);
    auto decayLabelArea6 = decay6.removeFromTop(decay6.getHeight() * 0.20);
    auto gain6 = section6.removeFromLeft(section6.getWidth() * 0.5);
    auto gainLabelArea6 = gain6.removeFromTop(gain6.getHeight() * 0.20);
    auto pan6 = section6;
    auto panLabelArea6 = pan6.removeFromTop(pan6.getHeight() * 0.20);
    
    auto section7 = area.removeFromTop(height * 0.125);
    section7 = section7.reduced(2);
    auto delay7 = section7.removeFromLeft(width * 0.66);
    auto delayLabelArea7 = delay7.removeFromTop(delay7.getHeight() * 0.20);
    auto units7 = section7.removeFromLeft(section7.getWidth() * 0.33);
    auto unitsLabelArea7 = units7.removeFromTop(units7.getHeight() * 0.20);
    auto decay7 = section7.removeFromLeft(section7.getWidth() * 0.33);
    auto decayLabelArea7 = decay7.removeFromTop(decay7.getHeight() * 0.20);
    auto gain7 = section7.removeFromLeft(section7.getWidth() * 0.5);
    auto gainLabelArea7 = gain7.removeFromTop(gain7.getHeight() * 0.20);
    auto pan7 = section7;
    auto panLabelArea7 = pan7.removeFromTop(pan7.getHeight() * 0.20);
    
    auto section8 = area.removeFromTop(height * 0.125);
    section8 = section8.reduced(2);
    auto delay8 = section8.removeFromLeft(width * 0.66);
    auto delayLabelArea8 = delay8.removeFromTop(delay8.getHeight() * 0.20);
    auto units8 = section8.removeFromLeft(section8.getWidth() * 0.33);
    auto unitsLabelArea8 = units8.removeFromTop(units8.getHeight() * 0.20);
    auto decay8 = section8.removeFromLeft(section8.getWidth() * 0.33);
    auto decayLabelArea8 = decay8.removeFromTop(decay8.getHeight() * 0.20);
    auto gain8 = section8.removeFromLeft(section8.getWidth() * 0.5);
    auto gainLabelArea8 = gain8.removeFromTop(gain8.getHeight() * 0.20);
    auto pan8 = section8;
    auto panLabelArea8 = pan8.removeFromTop(pan8.getHeight() * 0.20);
    
    
    delaySlider1.setBounds(delay1);
    delaySlider2.setBounds(delay2);
    delaySlider3.setBounds(delay3);
    delaySlider4.setBounds(delay4);
    delaySlider5.setBounds(delay5);
    delaySlider6.setBounds(delay6);
    delaySlider7.setBounds(delay7);
    delaySlider8.setBounds(delay8);
    
    delayLabel1.setBounds(delayLabelArea1);
    delayLabel2.setBounds(delayLabelArea2);
    delayLabel3.setBounds(delayLabelArea3);
    delayLabel4.setBounds(delayLabelArea4);
    delayLabel5.setBounds(delayLabelArea5);
    delayLabel6.setBounds(delayLabelArea6);
    delayLabel7.setBounds(delayLabelArea7);
    delayLabel8.setBounds(delayLabelArea8);
    
    unitsMenu1.setBounds(units1);
    unitsMenu2.setBounds(units2);
    unitsMenu3.setBounds(units3);
    unitsMenu4.setBounds(units4);
    unitsMenu5.setBounds(units5);
    unitsMenu6.setBounds(units6);
    unitsMenu7.setBounds(units7);
    unitsMenu8.setBounds(units8);
    
    unitsLabel1.setBounds(unitsLabelArea1);
    unitsLabel2.setBounds(unitsLabelArea2);
    unitsLabel3.setBounds(unitsLabelArea3);
    unitsLabel4.setBounds(unitsLabelArea4);
    unitsLabel5.setBounds(unitsLabelArea5);
    unitsLabel6.setBounds(unitsLabelArea6);
    unitsLabel7.setBounds(unitsLabelArea7);
    unitsLabel8.setBounds(unitsLabelArea8);
    
    decayKnob1.setBounds(decay1);
    decayKnob2.setBounds(decay2);
    decayKnob3.setBounds(decay3);
    decayKnob4.setBounds(decay4);
    decayKnob5.setBounds(decay5);
    decayKnob6.setBounds(decay6);
    decayKnob7.setBounds(decay7);
    decayKnob8.setBounds(decay8);
    
    decayLabel1.setBounds(decayLabelArea1);
    decayLabel2.setBounds(decayLabelArea2);
    decayLabel3.setBounds(decayLabelArea3);
    decayLabel4.setBounds(decayLabelArea4);
    decayLabel5.setBounds(decayLabelArea5);
    decayLabel6.setBounds(decayLabelArea6);
    decayLabel7.setBounds(decayLabelArea7);
    decayLabel8.setBounds(decayLabelArea8);
    
    gainKnob1.setBounds(gain1);
    gainKnob2.setBounds(gain2);
    gainKnob3.setBounds(gain3);
    gainKnob4.setBounds(gain4);
    gainKnob5.setBounds(gain5);
    gainKnob6.setBounds(gain6);
    gainKnob7.setBounds(gain7);
    gainKnob8.setBounds(gain8);
    
    gainLabel1.setBounds(gainLabelArea1);
    gainLabel2.setBounds(gainLabelArea2);
    gainLabel3.setBounds(gainLabelArea3);
    gainLabel4.setBounds(gainLabelArea4);
    gainLabel5.setBounds(gainLabelArea5);
    gainLabel6.setBounds(gainLabelArea6);
    gainLabel7.setBounds(gainLabelArea7);
    gainLabel8.setBounds(gainLabelArea8);
    
    panKnob1.setBounds(pan1);
    panKnob2.setBounds(pan2);
    panKnob3.setBounds(pan3);
    panKnob4.setBounds(pan4);
    panKnob5.setBounds(pan5);
    panKnob6.setBounds(pan6);
    panKnob7.setBounds(pan7);
    panKnob8.setBounds(pan8);
    
    panLabel1.setBounds(panLabelArea1);
    panLabel2.setBounds(panLabelArea2);
    panLabel3.setBounds(panLabelArea3);
    panLabel4.setBounds(panLabelArea4);
    panLabel5.setBounds(panLabelArea5);
    panLabel6.setBounds(panLabelArea6);
    panLabel7.setBounds(panLabelArea7);
    panLabel8.setBounds(panLabelArea8);
    
    
    
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
}
