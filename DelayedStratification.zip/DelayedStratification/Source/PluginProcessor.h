/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "faust/faustMinimalInlined1.h"

//==============================================================================
/**
*/
class DelayedStratificationAudioProcessor  : public juce::AudioProcessor, private juce::AudioProcessorValueTreeState::Listener
{
public:
    //==============================================================================
    DelayedStratificationAudioProcessor();
    ~DelayedStratificationAudioProcessor() override;
    
#define JUCEPARAMDELAY1 "delay1"
#define JUCEPARAMUNITS1 "units1"
#define JUCEPARAMDECAY1 "decay1"
#define JUCEPARAMGAIN1 "gain1"
#define JUCEPARAMPAN1 "pan1"
    
#define JUCEPARAMDELAY2 "delay2"
#define JUCEPARAMUNITS2 "units2"
#define JUCEPARAMDECAY2 "decay2"
#define JUCEPARAMGAIN2 "gain2"
#define JUCEPARAMPAN2 "pan2"
    
#define JUCEPARAMDELAY3 "delay3"
#define JUCEPARAMUNITS3 "units3"
#define JUCEPARAMDECAY3 "decay3"
#define JUCEPARAMGAIN3 "gain3"
#define JUCEPARAMPAN3 "pan3"
    
#define JUCEPARAMDELAY4 "delay4"
#define JUCEPARAMUNITS4 "units4"
#define JUCEPARAMDECAY4 "decay4"
#define JUCEPARAMGAIN4 "gain4"
#define JUCEPARAMPAN4 "pan4"

#define JUCEPARAMDELAY5 "delay5"
#define JUCEPARAMUNITS5 "units5"
#define JUCEPARAMDECAY5 "decay5"
#define JUCEPARAMGAIN5 "gain5"
#define JUCEPARAMPAN5 "pan5"
    
#define JUCEPARAMDELAY6 "delay6"
#define JUCEPARAMUNITS6 "units6"
#define JUCEPARAMDECAY6 "decay6"
#define JUCEPARAMGAIN6 "gain6"
#define JUCEPARAMPAN6 "pan6"
    
#define JUCEPARAMDELAY7 "delay7"
#define JUCEPARAMUNITS7 "units7"
#define JUCEPARAMDECAY7 "decay7"
#define JUCEPARAMGAIN7 "gain7"
#define JUCEPARAMPAN7 "pan7"
    
#define JUCEPARAMDELAY8 "delay8"
#define JUCEPARAMUNITS8 "units8"
#define JUCEPARAMDECAY8 "decay8"
#define JUCEPARAMGAIN8 "gain8"
#define JUCEPARAMPAN8 "pan8"
    
#define FAUSTPARAMDELAY1 "/Sparky's_Final_Project/Line_1/Delay"
#define FAUSTPARAMUNITS1 "/Sparky's_Final_Project/Line_1/Units"
#define FAUSTPARAMDECAY1 "/Sparky's_Final_Project/Line_1/Decay"
#define FAUSTPARAMGAIN1 "/Sparky's_Final_Project/Line_1/Gain"
#define FAUSTPARAMPAN1 "/Sparky's_Final_Project/Line_1/Pan"

#define FAUSTPARAMDELAY2 "/Sparky's_Final_Project/Line_2/Delay"
#define FAUSTPARAMUNITS2 "/Sparky's_Final_Project/Line_2/Units"
#define FAUSTPARAMDECAY2 "/Sparky's_Final_Project/Line_2/Decay"
#define FAUSTPARAMGAIN2 "/Sparky's_Final_Project/Line_2/Gain"
#define FAUSTPARAMPAN2 "/Sparky's_Final_Project/Line_2/Pan"
    
#define FAUSTPARAMDELAY3 "/Sparky's_Final_Project/Line_3/Delay"
#define FAUSTPARAMUNITS3 "/Sparky's_Final_Project/Line_3/Units"
#define FAUSTPARAMDECAY3 "/Sparky's_Final_Project/Line_3/Decay"
#define FAUSTPARAMGAIN3 "/Sparky's_Final_Project/Line_3/Gain"
#define FAUSTPARAMPAN3 "/Sparky's_Final_Project/Line_3/Pan"
    
#define FAUSTPARAMDELAY4 "/Sparky's_Final_Project/Line_4/Delay"
#define FAUSTPARAMUNITS4 "/Sparky's_Final_Project/Line_4/Units"
#define FAUSTPARAMDECAY4 "/Sparky's_Final_Project/Line_4/Decay"
#define FAUSTPARAMGAIN4 "/Sparky's_Final_Project/Line_4/Gain"
#define FAUSTPARAMPAN4 "/Sparky's_Final_Project/Line_4/Pan"
    
#define FAUSTPARAMDELAY5 "/Sparky's_Final_Project/Line_5/Delay"
#define FAUSTPARAMUNITS5 "/Sparky's_Final_Project/Line_5/Units"
#define FAUSTPARAMDECAY5 "/Sparky's_Final_Project/Line_5/Decay"
#define FAUSTPARAMGAIN5 "/Sparky's_Final_Project/Line_5/Gain"
#define FAUSTPARAMPAN5 "/Sparky's_Final_Project/Line_5/Pan"
    
#define FAUSTPARAMDELAY6 "/Sparky's_Final_Project/Line_6/Delay"
#define FAUSTPARAMUNITS6 "/Sparky's_Final_Project/Line_6/Units"
#define FAUSTPARAMDECAY6 "/Sparky's_Final_Project/Line_6/Decay"
#define FAUSTPARAMGAIN6 "/Sparky's_Final_Project/Line_6/Gain"
#define FAUSTPARAMPAN6 "/Sparky's_Final_Project/Line_6/Pan"
    
#define FAUSTPARAMDELAY7 "/Sparky's_Final_Project/Line_7/Delay"
#define FAUSTPARAMUNITS7 "/Sparky's_Final_Project/Line_7/Units"
#define FAUSTPARAMDECAY7 "/Sparky's_Final_Project/Line_7/Decay"
#define FAUSTPARAMGAIN7 "/Sparky's_Final_Project/Line_7/Gain"
#define FAUSTPARAMPAN7 "/Sparky's_Final_Project/Line_7/Pan"
    
#define FAUSTPARAMDELAY8 "/Sparky's_Final_Project/Line_8/Delay"
#define FAUSTPARAMUNITS8 "/Sparky's_Final_Project/Line_8/Units"
#define FAUSTPARAMDECAY8 "/Sparky's_Final_Project/Line_8/Decay"
#define FAUSTPARAMGAIN8 "/Sparky's_Final_Project/Line_8/Gain"
#define FAUSTPARAMPAN8 "/Sparky's_Final_Project/Line_8/Pan"
    
#define NUM_DELAY_LINES 8
#define NUM_PARAMS_PER_LINE 5
    
    const std::string JUCE_PARAMS[NUM_DELAY_LINES][NUM_PARAMS_PER_LINE] = {
        {
            JUCEPARAMDELAY1, JUCEPARAMUNITS1, JUCEPARAMDECAY1, JUCEPARAMGAIN1, JUCEPARAMPAN1
        },
        {
            JUCEPARAMDELAY2, JUCEPARAMUNITS2, JUCEPARAMDECAY2, JUCEPARAMGAIN2, JUCEPARAMPAN2
        },
        {
            JUCEPARAMDELAY3, JUCEPARAMUNITS3, JUCEPARAMDECAY3, JUCEPARAMGAIN3, JUCEPARAMPAN3
        },
        {
            JUCEPARAMDELAY4, JUCEPARAMUNITS4, JUCEPARAMDECAY4, JUCEPARAMGAIN4, JUCEPARAMPAN4
        },
        {
            JUCEPARAMDELAY5, JUCEPARAMUNITS5, JUCEPARAMDECAY5, JUCEPARAMGAIN5, JUCEPARAMPAN5
        },
        {
            JUCEPARAMDELAY6, JUCEPARAMUNITS6, JUCEPARAMDECAY6, JUCEPARAMGAIN6, JUCEPARAMPAN6
        },
        {
            JUCEPARAMDELAY7, JUCEPARAMUNITS7, JUCEPARAMDECAY7, JUCEPARAMGAIN7, JUCEPARAMPAN7
        },
        {
            JUCEPARAMDELAY8, JUCEPARAMUNITS8, JUCEPARAMDECAY8, JUCEPARAMGAIN8, JUCEPARAMPAN8
        }
    };
    
const std::string unit_names[2] = {"0.01 seconds", "seconds"};
    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;
    
    void parameterChanged(const juce::String &parameterID, float newValue) override;
    
    juce::AudioProcessorValueTreeState apvts;

private:
    MapUI * fUI;
    dsp * fDSP;
    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DelayedStratificationAudioProcessor)
};
