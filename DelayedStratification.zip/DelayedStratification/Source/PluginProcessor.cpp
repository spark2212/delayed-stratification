/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
DelayedStratificationAudioProcessor::DelayedStratificationAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       ),
apvts(*this, nullptr, juce::Identifier("DelayLine"), {
    std::make_unique<juce::AudioParameterFloat>(
                                                                                                  JUCEPARAMDELAY1, "Delay",
                                                                                                  juce::NormalisableRange<float>(0, 100, 1, 1),
                                                                                                  0),
    std::make_unique<juce::AudioParameterInt>(
                                                JUCEPARAMUNITS1, "Units",
                                                    0,
                                                    1,
                                                    0
                                            ),
    std::make_unique<juce::AudioParameterFloat>(
                                                    JUCEPARAMDECAY1,
                                                "Decay",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                    1),
    
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMGAIN1,
                                                "Gain",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                    0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMPAN1,
                                                "Pan",
                                                juce::NormalisableRange<float>(-1, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDELAY2, "Delay",
                                                juce::NormalisableRange<float>(0, 100, 1, 1),
                                                0),
    std::make_unique<juce::AudioParameterInt>(
                                                JUCEPARAMUNITS2, "Units",
                                                0,
                                                1,
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDECAY2,
                                                "Decay",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                1),
    
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMGAIN2,
                                                "Gain",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMPAN2,
                                                "Pan",
                                                juce::NormalisableRange<float>(-1, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDELAY3, "Delay",
                                                juce::NormalisableRange<float>(0, 100, 1, 1),
                                                0),
    std::make_unique<juce::AudioParameterInt>(
                                                JUCEPARAMUNITS3, "Units",
                                                0,
                                                1,
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDECAY3,
                                                "Decay",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                1),
    
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMGAIN3,
                                                "Gain",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMPAN3,
                                                "Pan",
                                                juce::NormalisableRange<float>(-1, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDELAY4, "Delay",
                                                juce::NormalisableRange<float>(0, 100, 1, 1),
                                                0),
    std::make_unique<juce::AudioParameterInt>(
                                                JUCEPARAMUNITS4, "Units",
                                                0,
                                                1,
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDECAY4,
                                                "Decay",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                1),
    
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMGAIN4,
                                                "Gain",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMPAN4,
                                                "Pan",
                                                juce::NormalisableRange<float>(-1, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDELAY5, "Delay",
                                                juce::NormalisableRange<float>(0, 100, 1, 1),
                                                0),
    std::make_unique<juce::AudioParameterInt>(
                                                JUCEPARAMUNITS5, "Units",
                                                0,
                                                1,
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDECAY5,
                                                "Decay",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                1),
    
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMGAIN5,
                                                "Gain",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMPAN5,
                                                "Pan",
                                                juce::NormalisableRange<float>(-1, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDELAY6, "Delay",
                                                juce::NormalisableRange<float>(0, 100, 1, 1),
                                                0),
    std::make_unique<juce::AudioParameterInt>(
                                                JUCEPARAMUNITS6, "Units",
                                                0,
                                                1,
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDECAY6,
                                                "Decay",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                1),
    
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMGAIN6,
                                                "Gain",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMPAN6,
                                                "Pan",
                                                juce::NormalisableRange<float>(-1, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDELAY7, "Delay",
                                                juce::NormalisableRange<float>(0, 100, 1, 1),
                                                0),
    std::make_unique<juce::AudioParameterInt>(
                                                JUCEPARAMUNITS7, "Units",
                                                0,
                                                1,
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDECAY7,
                                                "Decay",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                1),
    
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMGAIN7,
                                                "Gain",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMPAN7,
                                                "Pan",
                                                juce::NormalisableRange<float>(-1, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDELAY8, "Delay",
                                                juce::NormalisableRange<float>(0, 100, 1, 1),
                                                0),
    std::make_unique<juce::AudioParameterInt>(
                                                JUCEPARAMUNITS8, "Units",
                                                0,
                                                1,
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMDECAY8,
                                                "Decay",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                1),
    
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMGAIN8,
                                                "Gain",
                                                juce::NormalisableRange<float>(0, 1, 0.01, 1),
                                                0
                                                ),
    std::make_unique<juce::AudioParameterFloat>(
                                                JUCEPARAMPAN8,
                                                "Pan",
                                                juce::NormalisableRange<float>(-1, 1, 0.01, 1),
                                                0
                                                )
})
#endif
{
    DBG("Processor constructor");
    for(int i = 0; i < NUM_DELAY_LINES; i++)
    {
        for(int j = 0; j < NUM_PARAMS_PER_LINE; j++)
        {
            apvts.addParameterListener(JUCE_PARAMS[i][j], this);
        }
    }
}

DelayedStratificationAudioProcessor::~DelayedStratificationAudioProcessor()
{
    DBG("Processor destructor");
    delete fDSP;
    delete fUI;
    
    for(int i = 0; i < NUM_DELAY_LINES; i++)
    {
        for(int j = 0; j < NUM_PARAMS_PER_LINE; j++)
        {
            apvts.removeParameterListener(JUCE_PARAMS[i][j], this);
        }
    }
}

//==============================================================================
const juce::String DelayedStratificationAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool DelayedStratificationAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool DelayedStratificationAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool DelayedStratificationAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double DelayedStratificationAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int DelayedStratificationAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int DelayedStratificationAudioProcessor::getCurrentProgram()
{
    return 0;
}

void DelayedStratificationAudioProcessor::setCurrentProgram (int index)
{
}

const juce::String DelayedStratificationAudioProcessor::getProgramName (int index)
{
    return {};
}

void DelayedStratificationAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void DelayedStratificationAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // Use this method as the place to do any pre-playback
    // initialisation that you need..
    DBG("prepareToPlay");
    
    fDSP = new mydsp();
    fDSP -> init(sampleRate);
    fUI = new MapUI();
    fDSP -> buildUserInterface(fUI);
    
    DBG("faust parameters: " << fUI -> getParamsCount());
    for(auto i = 0; i < fUI -> getParamsCount(); ++i)
    {
        DBG(i << ": " << fUI -> getParamAddress(i));
    }
}

void DelayedStratificationAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
    DBG("Release resources");
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool DelayedStratificationAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void DelayedStratificationAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    /*auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();
    
    DBG("totalNumInputChannels == " << totalNumInputChannels);

    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    // This is the place where you'd normally do the guts of your plugin's
    // audio processing...
    // Make sure to reset the state if your inner loop is processing
    // the samples and the outer loop is handling the channels.
    // Alternatively, you can process the samples with the channels
    // interleaved by keeping the same state.
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto* channelData = buffer.getWritePointer (channel);

        // ..do something to the data...
    }*/
    
    auto audioArray = buffer.getArrayOfWritePointers();
    fDSP -> compute(buffer.getNumSamples(), audioArray, audioArray);
}

//==============================================================================
bool DelayedStratificationAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* DelayedStratificationAudioProcessor::createEditor()
{
    //return new juce::GenericAudioProcessorEditor (*this);
    return new DelayedStratificationAudioProcessorEditor (*this);
}

//==============================================================================
void DelayedStratificationAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
    DBG("getStateInformation");
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void DelayedStratificationAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
    DBG("setStateInformation");
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if(xmlState != nullptr)
    {
        if(xmlState -> hasTagName(apvts.state.getType()))
        {
            apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        }
    }
}

void DelayedStratificationAudioProcessor::parameterChanged(const juce::String &parameterID, float newValue)
{
    //float newUnitsValue = newValue - 1;
    
    if(parameterID == JUCEPARAMPAN1)
    {
        DBG("Line 1 Pan: " << newValue);
        fUI -> setParamValue(FAUSTPARAMPAN1, newValue);
    }
    else if(parameterID == JUCEPARAMPAN2)
    {
        DBG("Line 2 Pan: " << newValue);
        fUI -> setParamValue(FAUSTPARAMPAN2, newValue);
    }
    else if(parameterID == JUCEPARAMPAN3)
    {
        DBG("Line 3 Pan: " << newValue);
        fUI -> setParamValue(FAUSTPARAMPAN3, newValue);
    }
    else if(parameterID == JUCEPARAMPAN4)
    {
        DBG("Line 4 Pan: " << newValue);
        fUI -> setParamValue(FAUSTPARAMPAN4, newValue);
    }
    else if(parameterID == JUCEPARAMPAN5)
    {
        DBG("Line 5 Pan: " << newValue);
        fUI -> setParamValue(FAUSTPARAMPAN5, newValue);
    }
    else if(parameterID == JUCEPARAMPAN6)
    {
        DBG("Line 6 Pan: " << newValue);
        fUI -> setParamValue(FAUSTPARAMPAN6, newValue);
    }
    else if(parameterID == JUCEPARAMPAN7)
    {
        DBG("Line 7 Pan: " << newValue);
        fUI -> setParamValue(FAUSTPARAMPAN7, newValue);
    }
    else if(parameterID == JUCEPARAMPAN8)
    {
        DBG("Line 8 Pan: " << newValue);
        fUI -> setParamValue(FAUSTPARAMPAN8, newValue);
    }
    else if(parameterID == JUCEPARAMGAIN1)
    {
        DBG("Line 1 Gain: " << newValue);
        fUI -> setParamValue(FAUSTPARAMGAIN1, newValue);
    }
    else if(parameterID == JUCEPARAMGAIN2)
    {
        DBG("Line 2 Gain: " << newValue);
        fUI -> setParamValue(FAUSTPARAMGAIN2, newValue);
    }
    else if(parameterID == JUCEPARAMGAIN3)
    {
        DBG("Line 3 Gain: " << newValue);
        fUI -> setParamValue(FAUSTPARAMGAIN3, newValue);
    }
    else if(parameterID == JUCEPARAMGAIN4)
    {
        DBG("Line 4 Gain: " << newValue);
        fUI -> setParamValue(FAUSTPARAMGAIN4, newValue);
    }
    else if(parameterID == JUCEPARAMGAIN5)
    {
        DBG("Line 5 Gain: " << newValue);
        fUI -> setParamValue(FAUSTPARAMGAIN5, newValue);
    }
    else if(parameterID == JUCEPARAMGAIN6)
    {
        DBG("Line 6 Gain: " << newValue);
        fUI -> setParamValue(FAUSTPARAMGAIN6, newValue);
    }
    else if(parameterID == JUCEPARAMGAIN7)
    {
        DBG("Line 7 Gain: " << newValue);
        fUI -> setParamValue(FAUSTPARAMGAIN7, newValue);
    }
    else if(parameterID == JUCEPARAMGAIN8)
    {
        DBG("Line 8 Gain: " << newValue);
        fUI -> setParamValue(FAUSTPARAMGAIN8, newValue);
    }
    else if(parameterID == JUCEPARAMDELAY1)
    {
        DBG("Line 1 Delay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDELAY1, newValue);
    }
    else if(parameterID == JUCEPARAMDELAY2)
    {
        DBG("Line 2 Delay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDELAY2, newValue);
    }
    else if(parameterID == JUCEPARAMDELAY3)
    {
        DBG("Line 3 Delay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDELAY3, newValue);
    }
    else if(parameterID == JUCEPARAMDELAY4)
    {
        DBG("Line 4 Delay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDELAY4, newValue);
    }
    else if(parameterID == JUCEPARAMDELAY5)
    {
        DBG("Line 5 Delay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDELAY5, newValue);
    }
    else if(parameterID == JUCEPARAMDELAY6)
    {
        DBG("Line 6 Delay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDELAY6, newValue);
    }
    else if(parameterID == JUCEPARAMDELAY7)
    {
        DBG("Line 7 Delay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDELAY7, newValue);
    }
    else if(parameterID == JUCEPARAMDELAY8)
    {
        DBG("Line 8 Delay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDELAY8, newValue);
    }
    else if(parameterID == JUCEPARAMDECAY1)
    {
        DBG("Line 1 Decay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDECAY1, newValue);
    }
    else if(parameterID == JUCEPARAMDECAY2)
    {
        DBG("Line 2 Decay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDECAY2, newValue);
    }
    else if(parameterID == JUCEPARAMDECAY3)
    {
        DBG("Line 3 Decay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDECAY3, newValue);
    }
    else if(parameterID == JUCEPARAMDECAY4)
    {
        DBG("Line 4 Decay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDECAY4, newValue);
    }
    else if(parameterID == JUCEPARAMDECAY5)
    {
        DBG("Line 5 Decay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDECAY5, newValue);
    }
    else if(parameterID == JUCEPARAMDECAY6)
    {
        DBG("Line 6 Decay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDECAY6, newValue);
    }
    else if(parameterID == JUCEPARAMDECAY7)
    {
        DBG("Line 7 Decay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDECAY7, newValue);
    }
    else if(parameterID == JUCEPARAMDECAY8)
    {
        DBG("Line 8 Decay: " << newValue);
        fUI -> setParamValue(FAUSTPARAMDECAY8, newValue);
    }
    else if(parameterID == JUCEPARAMUNITS1)
    {
        DBG("Line 1 Units: " << unit_names[(int) newValue]);
        fUI -> setParamValue(FAUSTPARAMUNITS1, newValue);
    }
    else if(parameterID == JUCEPARAMUNITS2)
    {
        DBG("Line 2 Units: " << unit_names[(int) newValue]);
        fUI -> setParamValue(FAUSTPARAMUNITS2, newValue);
    }
    else if(parameterID == JUCEPARAMUNITS3)
    {
        DBG("Line 3 Units: " << unit_names[(int) newValue]);
        fUI -> setParamValue(FAUSTPARAMUNITS3, newValue);
    }
    else if(parameterID == JUCEPARAMUNITS4)
    {
        DBG("Line 4 Units: " << unit_names[(int) newValue]);
        fUI -> setParamValue(FAUSTPARAMUNITS4, newValue);
    }
    else if(parameterID == JUCEPARAMUNITS5)
    {
        DBG("Line 5 Units: " << unit_names[(int) newValue]);
        fUI -> setParamValue(FAUSTPARAMUNITS5, newValue);
    }
    else if(parameterID == JUCEPARAMUNITS6)
    {
        DBG("Line 6 Units: " << unit_names[(int) newValue]);
        fUI -> setParamValue(FAUSTPARAMUNITS6, newValue);
    }
    else if(parameterID == JUCEPARAMUNITS7)
    {
        DBG("Line 7 Units: " << unit_names[(int) newValue]);
        fUI -> setParamValue(FAUSTPARAMUNITS7, newValue);
    }
    else if(parameterID == JUCEPARAMUNITS8)
    {
        DBG("Line 8 Units: " << unit_names[(int) newValue]);
        fUI -> setParamValue(FAUSTPARAMUNITS8, newValue);
    }
    else
    {
        DBG("parameterChanged: " << parameterID << " " << newValue);
    }
    
}


//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new DelayedStratificationAudioProcessor();
}
