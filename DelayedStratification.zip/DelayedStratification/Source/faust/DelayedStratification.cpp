/* ------------------------------------------------------------
name: "DelayedStratification"
Code generated with Faust 2.30.7 (https://faust.grame.fr)
Compilation options: -lang cpp -es 1 -scal -ftz 0
------------------------------------------------------------ */

#ifndef  __mydsp_H__
#define  __mydsp_H__

#ifndef FAUSTFLOAT
#define FAUSTFLOAT float
#endif 

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <math.h>


#ifndef FAUSTCLASS 
#define FAUSTCLASS mydsp
#endif

#ifdef __APPLE__ 
#define exp10f __exp10f
#define exp10 __exp10
#endif

class mydsp : public dsp {
	
 private:
	
	FAUSTFLOAT fHslider0;
	float fRec1[2];
	int fSampleRate;
	float fConst0;
	FAUSTFLOAT fHslider1;
	FAUSTFLOAT fHslider2;
	FAUSTFLOAT fHslider3;
	float fRec2[2];
	int IOTA;
	float fVec0[33554432];
	float fRec0[33554432];
	FAUSTFLOAT fHslider4;
	float fRec3[2];
	FAUSTFLOAT fHslider5;
	float fRec5[2];
	FAUSTFLOAT fHslider6;
	FAUSTFLOAT fHslider7;
	FAUSTFLOAT fHslider8;
	float fRec6[2];
	float fVec1[33554432];
	float fRec4[33554432];
	FAUSTFLOAT fHslider9;
	float fRec7[2];
	FAUSTFLOAT fHslider10;
	float fRec9[2];
	FAUSTFLOAT fHslider11;
	FAUSTFLOAT fHslider12;
	FAUSTFLOAT fHslider13;
	float fRec10[2];
	float fVec2[33554432];
	float fRec8[33554432];
	FAUSTFLOAT fHslider14;
	float fRec11[2];
	FAUSTFLOAT fHslider15;
	float fRec13[2];
	FAUSTFLOAT fHslider16;
	FAUSTFLOAT fHslider17;
	FAUSTFLOAT fHslider18;
	float fRec14[2];
	float fVec3[33554432];
	float fRec12[33554432];
	FAUSTFLOAT fHslider19;
	float fRec15[2];
	FAUSTFLOAT fHslider20;
	float fRec17[2];
	FAUSTFLOAT fHslider21;
	FAUSTFLOAT fHslider22;
	FAUSTFLOAT fHslider23;
	float fRec18[2];
	float fVec4[33554432];
	float fRec16[33554432];
	FAUSTFLOAT fHslider24;
	float fRec19[2];
	FAUSTFLOAT fHslider25;
	float fRec21[2];
	FAUSTFLOAT fHslider26;
	FAUSTFLOAT fHslider27;
	FAUSTFLOAT fHslider28;
	float fRec22[2];
	float fVec5[33554432];
	float fRec20[33554432];
	FAUSTFLOAT fHslider29;
	float fRec23[2];
	FAUSTFLOAT fHslider30;
	float fRec25[2];
	FAUSTFLOAT fHslider31;
	FAUSTFLOAT fHslider32;
	FAUSTFLOAT fHslider33;
	float fRec26[2];
	float fVec6[33554432];
	float fRec24[33554432];
	FAUSTFLOAT fHslider34;
	float fRec27[2];
	FAUSTFLOAT fHslider35;
	float fRec29[2];
	FAUSTFLOAT fHslider36;
	FAUSTFLOAT fHslider37;
	FAUSTFLOAT fHslider38;
	float fRec30[2];
	float fVec7[33554432];
	float fRec28[33554432];
	FAUSTFLOAT fHslider39;
	float fRec31[2];
	
 public:
	
	void metadata(Meta* m) { 
		m->declare("compile_options", "-lang cpp -es 1 -scal -ftz 0");
		m->declare("filename", "DelayedStratification.dsp");
		m->declare("maths.lib/author", "GRAME");
		m->declare("maths.lib/copyright", "GRAME");
		m->declare("maths.lib/license", "LGPL with exception");
		m->declare("maths.lib/name", "Faust Math Library");
		m->declare("maths.lib/version", "2.3");
		m->declare("name", "DelayedStratification");
		m->declare("platform.lib/name", "Generic Platform Library");
		m->declare("platform.lib/version", "0.1");
		m->declare("signals.lib/name", "Faust Signal Routing Library");
		m->declare("signals.lib/version", "0.0");
		m->declare("spats.lib/name", "Faust Spatialization Library");
		m->declare("spats.lib/version", "0.0");
	}

	virtual int getNumInputs() {
		return 2;
	}
	virtual int getNumOutputs() {
		return 2;
	}
	virtual int getInputRate(int channel) {
		int rate;
		switch ((channel)) {
			case 0: {
				rate = 1;
				break;
			}
			case 1: {
				rate = 1;
				break;
			}
			default: {
				rate = -1;
				break;
			}
		}
		return rate;
	}
	virtual int getOutputRate(int channel) {
		int rate;
		switch ((channel)) {
			case 0: {
				rate = 1;
				break;
			}
			case 1: {
				rate = 1;
				break;
			}
			default: {
				rate = -1;
				break;
			}
		}
		return rate;
	}
	
	static void classInit(int sample_rate) {
	}
	
	virtual void instanceConstants(int sample_rate) {
		fSampleRate = sample_rate;
		fConst0 = std::min<float>(192000.0f, std::max<float>(1.0f, float(fSampleRate)));
	}
	
	virtual void instanceResetUserInterface() {
		fHslider0 = FAUSTFLOAT(1.0f);
		fHslider1 = FAUSTFLOAT(0.0f);
		fHslider2 = FAUSTFLOAT(0.0f);
		fHslider3 = FAUSTFLOAT(0.0f);
		fHslider4 = FAUSTFLOAT(0.0f);
		fHslider5 = FAUSTFLOAT(1.0f);
		fHslider6 = FAUSTFLOAT(0.0f);
		fHslider7 = FAUSTFLOAT(0.0f);
		fHslider8 = FAUSTFLOAT(0.0f);
		fHslider9 = FAUSTFLOAT(0.0f);
		fHslider10 = FAUSTFLOAT(1.0f);
		fHslider11 = FAUSTFLOAT(0.0f);
		fHslider12 = FAUSTFLOAT(0.0f);
		fHslider13 = FAUSTFLOAT(0.0f);
		fHslider14 = FAUSTFLOAT(0.0f);
		fHslider15 = FAUSTFLOAT(1.0f);
		fHslider16 = FAUSTFLOAT(0.0f);
		fHslider17 = FAUSTFLOAT(0.0f);
		fHslider18 = FAUSTFLOAT(0.0f);
		fHslider19 = FAUSTFLOAT(0.0f);
		fHslider20 = FAUSTFLOAT(1.0f);
		fHslider21 = FAUSTFLOAT(0.0f);
		fHslider22 = FAUSTFLOAT(0.0f);
		fHslider23 = FAUSTFLOAT(0.0f);
		fHslider24 = FAUSTFLOAT(0.0f);
		fHslider25 = FAUSTFLOAT(1.0f);
		fHslider26 = FAUSTFLOAT(0.0f);
		fHslider27 = FAUSTFLOAT(0.0f);
		fHslider28 = FAUSTFLOAT(0.0f);
		fHslider29 = FAUSTFLOAT(0.0f);
		fHslider30 = FAUSTFLOAT(1.0f);
		fHslider31 = FAUSTFLOAT(0.0f);
		fHslider32 = FAUSTFLOAT(0.0f);
		fHslider33 = FAUSTFLOAT(0.0f);
		fHslider34 = FAUSTFLOAT(0.0f);
		fHslider35 = FAUSTFLOAT(1.0f);
		fHslider36 = FAUSTFLOAT(0.0f);
		fHslider37 = FAUSTFLOAT(0.0f);
		fHslider38 = FAUSTFLOAT(0.0f);
		fHslider39 = FAUSTFLOAT(0.0f);
	}
	
	virtual void instanceClear() {
		for (int l0 = 0; (l0 < 2); l0 = (l0 + 1)) {
			fRec1[l0] = 0.0f;
		}
		for (int l1 = 0; (l1 < 2); l1 = (l1 + 1)) {
			fRec2[l1] = 0.0f;
		}
		IOTA = 0;
		for (int l2 = 0; (l2 < 33554432); l2 = (l2 + 1)) {
			fVec0[l2] = 0.0f;
		}
		for (int l3 = 0; (l3 < 33554432); l3 = (l3 + 1)) {
			fRec0[l3] = 0.0f;
		}
		for (int l4 = 0; (l4 < 2); l4 = (l4 + 1)) {
			fRec3[l4] = 0.0f;
		}
		for (int l5 = 0; (l5 < 2); l5 = (l5 + 1)) {
			fRec5[l5] = 0.0f;
		}
		for (int l6 = 0; (l6 < 2); l6 = (l6 + 1)) {
			fRec6[l6] = 0.0f;
		}
		for (int l7 = 0; (l7 < 33554432); l7 = (l7 + 1)) {
			fVec1[l7] = 0.0f;
		}
		for (int l8 = 0; (l8 < 33554432); l8 = (l8 + 1)) {
			fRec4[l8] = 0.0f;
		}
		for (int l9 = 0; (l9 < 2); l9 = (l9 + 1)) {
			fRec7[l9] = 0.0f;
		}
		for (int l10 = 0; (l10 < 2); l10 = (l10 + 1)) {
			fRec9[l10] = 0.0f;
		}
		for (int l11 = 0; (l11 < 2); l11 = (l11 + 1)) {
			fRec10[l11] = 0.0f;
		}
		for (int l12 = 0; (l12 < 33554432); l12 = (l12 + 1)) {
			fVec2[l12] = 0.0f;
		}
		for (int l13 = 0; (l13 < 33554432); l13 = (l13 + 1)) {
			fRec8[l13] = 0.0f;
		}
		for (int l14 = 0; (l14 < 2); l14 = (l14 + 1)) {
			fRec11[l14] = 0.0f;
		}
		for (int l15 = 0; (l15 < 2); l15 = (l15 + 1)) {
			fRec13[l15] = 0.0f;
		}
		for (int l16 = 0; (l16 < 2); l16 = (l16 + 1)) {
			fRec14[l16] = 0.0f;
		}
		for (int l17 = 0; (l17 < 33554432); l17 = (l17 + 1)) {
			fVec3[l17] = 0.0f;
		}
		for (int l18 = 0; (l18 < 33554432); l18 = (l18 + 1)) {
			fRec12[l18] = 0.0f;
		}
		for (int l19 = 0; (l19 < 2); l19 = (l19 + 1)) {
			fRec15[l19] = 0.0f;
		}
		for (int l20 = 0; (l20 < 2); l20 = (l20 + 1)) {
			fRec17[l20] = 0.0f;
		}
		for (int l21 = 0; (l21 < 2); l21 = (l21 + 1)) {
			fRec18[l21] = 0.0f;
		}
		for (int l22 = 0; (l22 < 33554432); l22 = (l22 + 1)) {
			fVec4[l22] = 0.0f;
		}
		for (int l23 = 0; (l23 < 33554432); l23 = (l23 + 1)) {
			fRec16[l23] = 0.0f;
		}
		for (int l24 = 0; (l24 < 2); l24 = (l24 + 1)) {
			fRec19[l24] = 0.0f;
		}
		for (int l25 = 0; (l25 < 2); l25 = (l25 + 1)) {
			fRec21[l25] = 0.0f;
		}
		for (int l26 = 0; (l26 < 2); l26 = (l26 + 1)) {
			fRec22[l26] = 0.0f;
		}
		for (int l27 = 0; (l27 < 33554432); l27 = (l27 + 1)) {
			fVec5[l27] = 0.0f;
		}
		for (int l28 = 0; (l28 < 33554432); l28 = (l28 + 1)) {
			fRec20[l28] = 0.0f;
		}
		for (int l29 = 0; (l29 < 2); l29 = (l29 + 1)) {
			fRec23[l29] = 0.0f;
		}
		for (int l30 = 0; (l30 < 2); l30 = (l30 + 1)) {
			fRec25[l30] = 0.0f;
		}
		for (int l31 = 0; (l31 < 2); l31 = (l31 + 1)) {
			fRec26[l31] = 0.0f;
		}
		for (int l32 = 0; (l32 < 33554432); l32 = (l32 + 1)) {
			fVec6[l32] = 0.0f;
		}
		for (int l33 = 0; (l33 < 33554432); l33 = (l33 + 1)) {
			fRec24[l33] = 0.0f;
		}
		for (int l34 = 0; (l34 < 2); l34 = (l34 + 1)) {
			fRec27[l34] = 0.0f;
		}
		for (int l35 = 0; (l35 < 2); l35 = (l35 + 1)) {
			fRec29[l35] = 0.0f;
		}
		for (int l36 = 0; (l36 < 2); l36 = (l36 + 1)) {
			fRec30[l36] = 0.0f;
		}
		for (int l37 = 0; (l37 < 33554432); l37 = (l37 + 1)) {
			fVec7[l37] = 0.0f;
		}
		for (int l38 = 0; (l38 < 33554432); l38 = (l38 + 1)) {
			fRec28[l38] = 0.0f;
		}
		for (int l39 = 0; (l39 < 2); l39 = (l39 + 1)) {
			fRec31[l39] = 0.0f;
		}
	}
	
	virtual void init(int sample_rate) {
		classInit(sample_rate);
		instanceInit(sample_rate);
	}
	virtual void instanceInit(int sample_rate) {
		instanceConstants(sample_rate);
		instanceResetUserInterface();
		instanceClear();
	}
	
	virtual mydsp* clone() {
		return new mydsp();
	}
	
	virtual int getSampleRate() {
		return fSampleRate;
	}
	
	virtual void buildUserInterface(UI* ui_interface) {
        ui_interface->openVerticalBox("DelayedStratification");
        ui_interface->openHorizontalBox("Line 1");
        ui_interface->declare(&fHslider1, "1", "");
        ui_interface->addHorizontalSlider("Delay1", &fHslider1, 0.0f, 0.0f, 100.0f, 1.0f);
        ui_interface->declare(&fHslider2, "2", "");
        ui_interface->declare(&fHslider2, "style", "menu{'0.01 seconds':0;'seconds':1}");
        ui_interface->addHorizontalSlider("Units1", &fHslider2, 0.0f, 0.0f, 1.0f, 1.0f);
        ui_interface->declare(&fHslider0, "3", "");
        ui_interface->declare(&fHslider0, "style", "knob");
        ui_interface->addHorizontalSlider("Decay1", &fHslider0, 1.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider3, "4", "");
        ui_interface->declare(&fHslider3, "style", "knob");
        ui_interface->addHorizontalSlider("Gain1", &fHslider3, 0.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider4, "5", "");
        ui_interface->declare(&fHslider4, "style", "knob");
        ui_interface->addHorizontalSlider("Pan1", &fHslider4, 0.0f, -1.0f, 1.0f, 0.00999999978f);
        ui_interface->closeBox();
        ui_interface->openHorizontalBox("Line 2");
        ui_interface->declare(&fHslider6, "1", "");
        ui_interface->addHorizontalSlider("Delay2", &fHslider6, 0.0f, 0.0f, 100.0f, 1.0f);
        ui_interface->declare(&fHslider7, "2", "");
        ui_interface->declare(&fHslider7, "style", "menu{'0.01 seconds':0;'seconds':1}");
        ui_interface->addHorizontalSlider("Units2", &fHslider7, 0.0f, 0.0f, 1.0f, 1.0f);
        ui_interface->declare(&fHslider5, "3", "");
        ui_interface->declare(&fHslider5, "style", "knob");
        ui_interface->addHorizontalSlider("Decay2", &fHslider5, 1.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider8, "4", "");
        ui_interface->declare(&fHslider8, "style", "knob");
        ui_interface->addHorizontalSlider("Gain2", &fHslider8, 0.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider9, "5", "");
        ui_interface->declare(&fHslider9, "style", "knob");
        ui_interface->addHorizontalSlider("Pan2", &fHslider9, 0.0f, -1.0f, 1.0f, 0.00999999978f);
        ui_interface->closeBox();
        ui_interface->openHorizontalBox("Line 3");
        ui_interface->declare(&fHslider11, "1", "");
        ui_interface->addHorizontalSlider("Delay3", &fHslider11, 0.0f, 0.0f, 100.0f, 1.0f);
        ui_interface->declare(&fHslider12, "2", "");
        ui_interface->declare(&fHslider12, "style", "menu{'0.01 seconds':0;'seconds':1}");
        ui_interface->addHorizontalSlider("Units3", &fHslider12, 0.0f, 0.0f, 1.0f, 1.0f);
        ui_interface->declare(&fHslider10, "3", "");
        ui_interface->declare(&fHslider10, "style", "knob");
        ui_interface->addHorizontalSlider("Decay3", &fHslider10, 1.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider13, "4", "");
        ui_interface->declare(&fHslider13, "style", "knob");
        ui_interface->addHorizontalSlider("Gain3", &fHslider13, 0.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider14, "5", "");
        ui_interface->declare(&fHslider14, "style", "knob");
        ui_interface->addHorizontalSlider("Pan3", &fHslider14, 0.0f, -1.0f, 1.0f, 0.00999999978f);
        ui_interface->closeBox();
        ui_interface->openHorizontalBox("Line 4");
        ui_interface->declare(&fHslider16, "1", "");
        ui_interface->addHorizontalSlider("Delay4", &fHslider16, 0.0f, 0.0f, 100.0f, 1.0f);
        ui_interface->declare(&fHslider17, "2", "");
        ui_interface->declare(&fHslider17, "style", "menu{'0.01 seconds':0;'seconds':1}");
        ui_interface->addHorizontalSlider("Units4", &fHslider17, 0.0f, 0.0f, 1.0f, 1.0f);
        ui_interface->declare(&fHslider15, "3", "");
        ui_interface->declare(&fHslider15, "style", "knob");
        ui_interface->addHorizontalSlider("Decay4", &fHslider15, 1.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider18, "4", "");
        ui_interface->declare(&fHslider18, "style", "knob");
        ui_interface->addHorizontalSlider("Gain4", &fHslider18, 0.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider19, "5", "");
        ui_interface->declare(&fHslider19, "style", "knob");
        ui_interface->addHorizontalSlider("Pan4", &fHslider19, 0.0f, -1.0f, 1.0f, 0.00999999978f);
        ui_interface->closeBox();
        ui_interface->openHorizontalBox("Line 5");
        ui_interface->declare(&fHslider21, "1", "");
        ui_interface->addHorizontalSlider("Delay5", &fHslider21, 0.0f, 0.0f, 100.0f, 1.0f);
        ui_interface->declare(&fHslider22, "2", "");
        ui_interface->declare(&fHslider22, "style", "menu{'0.01 seconds':0;'seconds':1}");
        ui_interface->addHorizontalSlider("Units5", &fHslider22, 0.0f, 0.0f, 1.0f, 1.0f);
        ui_interface->declare(&fHslider20, "3", "");
        ui_interface->declare(&fHslider20, "style", "knob");
        ui_interface->addHorizontalSlider("Decay5", &fHslider20, 1.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider23, "4", "");
        ui_interface->declare(&fHslider23, "style", "knob");
        ui_interface->addHorizontalSlider("Gain5", &fHslider23, 0.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider24, "5", "");
        ui_interface->declare(&fHslider24, "style", "knob");
        ui_interface->addHorizontalSlider("Pan5", &fHslider24, 0.0f, -1.0f, 1.0f, 0.00999999978f);
        ui_interface->closeBox();
        ui_interface->openHorizontalBox("Line 6");
        ui_interface->declare(&fHslider26, "1", "");
        ui_interface->addHorizontalSlider("Delay6", &fHslider26, 0.0f, 0.0f, 100.0f, 1.0f);
        ui_interface->declare(&fHslider27, "2", "");
        ui_interface->declare(&fHslider27, "style", "menu{'0.01 seconds':0;'seconds':1}");
        ui_interface->addHorizontalSlider("Units6", &fHslider27, 0.0f, 0.0f, 1.0f, 1.0f);
        ui_interface->declare(&fHslider25, "3", "");
        ui_interface->declare(&fHslider25, "style", "knob");
        ui_interface->addHorizontalSlider("Decay6", &fHslider25, 1.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider28, "4", "");
        ui_interface->declare(&fHslider28, "style", "knob");
        ui_interface->addHorizontalSlider("Gain6", &fHslider28, 0.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider29, "5", "");
        ui_interface->declare(&fHslider29, "style", "knob");
        ui_interface->addHorizontalSlider("Pan6", &fHslider29, 0.0f, -1.0f, 1.0f, 0.00999999978f);
        ui_interface->closeBox();
        ui_interface->openHorizontalBox("Line 7");
        ui_interface->declare(&fHslider36, "1", "");
        ui_interface->addHorizontalSlider("Delay7", &fHslider36, 0.0f, 0.0f, 100.0f, 1.0f);
        ui_interface->declare(&fHslider37, "2", "");
        ui_interface->declare(&fHslider37, "style", "menu{'0.01 seconds':0;'seconds':1}");
        ui_interface->addHorizontalSlider("Units7", &fHslider37, 0.0f, 0.0f, 1.0f, 1.0f);
        ui_interface->declare(&fHslider35, "3", "");
        ui_interface->declare(&fHslider35, "style", "knob");
        ui_interface->addHorizontalSlider("Decay7", &fHslider35, 1.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider38, "4", "");
        ui_interface->declare(&fHslider38, "style", "knob");
        ui_interface->addHorizontalSlider("Gain7", &fHslider38, 0.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider39, "5", "");
        ui_interface->declare(&fHslider39, "style", "knob");
        ui_interface->addHorizontalSlider("Pan7", &fHslider39, 0.0f, -1.0f, 1.0f, 0.00999999978f);
        ui_interface->closeBox();
        ui_interface->openHorizontalBox("Line 8");
        ui_interface->declare(&fHslider31, "1", "");
        ui_interface->addHorizontalSlider("Delay8", &fHslider31, 0.0f, 0.0f, 100.0f, 1.0f);
        ui_interface->declare(&fHslider32, "2", "");
        ui_interface->declare(&fHslider32, "style", "menu{'0.01 seconds':0;'seconds':1}");
        ui_interface->addHorizontalSlider("Units8", &fHslider32, 0.0f, 0.0f, 1.0f, 1.0f);
        ui_interface->declare(&fHslider30, "3", "");
        ui_interface->declare(&fHslider30, "style", "knob");
        ui_interface->addHorizontalSlider("Decay8", &fHslider30, 1.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider33, "4", "");
        ui_interface->declare(&fHslider33, "style", "knob");
        ui_interface->addHorizontalSlider("Gain8", &fHslider33, 0.0f, 0.0f, 1.0f, 0.00999999978f);
        ui_interface->declare(&fHslider34, "5", "");
        ui_interface->declare(&fHslider34, "style", "knob");
        ui_interface->addHorizontalSlider("Pan8", &fHslider34, 0.0f, -1.0f, 1.0f, 0.00999999978f);
        ui_interface->closeBox();
        ui_interface->closeBox();
	}
	
	virtual void compute(int count, FAUSTFLOAT** inputs, FAUSTFLOAT** outputs) {
		FAUSTFLOAT* input0 = inputs[0];
		FAUSTFLOAT* input1 = inputs[1];
		FAUSTFLOAT* output0 = outputs[0];
		FAUSTFLOAT* output1 = outputs[1];
		float fSlow0 = (0.00100000005f * float(fHslider0));
		float fSlow1 = (fConst0 * (float(fHslider1) * std::pow(100.0f, (float(fHslider2) + -1.0f))));
		int iSlow2 = (int((fSlow1 + -1.0f)) + 1);
		float fSlow3 = (0.00100000005f * float(fHslider3));
		int iSlow4 = int(fSlow1);
		float fSlow5 = (0.00100000005f * float(fHslider4));
		float fSlow6 = (0.00100000005f * float(fHslider5));
		float fSlow7 = (fConst0 * (float(fHslider6) * std::pow(100.0f, (float(fHslider7) + -1.0f))));
		int iSlow8 = (int((fSlow7 + -1.0f)) + 1);
		float fSlow9 = (0.00100000005f * float(fHslider8));
		int iSlow10 = int(fSlow7);
		float fSlow11 = (0.00100000005f * float(fHslider9));
		float fSlow12 = (0.00100000005f * float(fHslider10));
		float fSlow13 = (fConst0 * (float(fHslider11) * std::pow(100.0f, (float(fHslider12) + -1.0f))));
		int iSlow14 = (int((fSlow13 + -1.0f)) + 1);
		float fSlow15 = (0.00100000005f * float(fHslider13));
		int iSlow16 = int(fSlow13);
		float fSlow17 = (0.00100000005f * float(fHslider14));
		float fSlow18 = (0.00100000005f * float(fHslider15));
		float fSlow19 = (fConst0 * (float(fHslider16) * std::pow(100.0f, (float(fHslider17) + -1.0f))));
		int iSlow20 = (int((fSlow19 + -1.0f)) + 1);
		float fSlow21 = (0.00100000005f * float(fHslider18));
		int iSlow22 = int(fSlow19);
		float fSlow23 = (0.00100000005f * float(fHslider19));
		float fSlow24 = (0.00100000005f * float(fHslider20));
		float fSlow25 = (fConst0 * (float(fHslider21) * std::pow(100.0f, (float(fHslider22) + -1.0f))));
		int iSlow26 = (int((fSlow25 + -1.0f)) + 1);
		float fSlow27 = (0.00100000005f * float(fHslider23));
		int iSlow28 = int(fSlow25);
		float fSlow29 = (0.00100000005f * float(fHslider24));
		float fSlow30 = (0.00100000005f * float(fHslider25));
		float fSlow31 = (fConst0 * (float(fHslider26) * std::pow(100.0f, (float(fHslider27) + -1.0f))));
		int iSlow32 = (int((fSlow31 + -1.0f)) + 1);
		float fSlow33 = (0.00100000005f * float(fHslider28));
		int iSlow34 = int(fSlow31);
		float fSlow35 = (0.00100000005f * float(fHslider29));
		float fSlow36 = (0.00100000005f * float(fHslider30));
		float fSlow37 = (fConst0 * (float(fHslider31) * std::pow(100.0f, (float(fHslider32) + -1.0f))));
		int iSlow38 = (int((fSlow37 + -1.0f)) + 1);
		float fSlow39 = (0.00100000005f * float(fHslider33));
		int iSlow40 = int(fSlow37);
		float fSlow41 = (0.00100000005f * float(fHslider34));
		float fSlow42 = (0.00100000005f * float(fHslider35));
		float fSlow43 = (fConst0 * (float(fHslider36) * std::pow(100.0f, (float(fHslider37) + -1.0f))));
		int iSlow44 = (int((fSlow43 + -1.0f)) + 1);
		float fSlow45 = (0.00100000005f * float(fHslider38));
		int iSlow46 = int(fSlow43);
		float fSlow47 = (0.00100000005f * float(fHslider39));
		for (int i = 0; (i < count); i = (i + 1)) {
			fRec1[0] = (fSlow0 + (0.999000013f * fRec1[1]));
			float fTemp0 = (float(input0[i]) + float(input1[i]));
			fRec2[0] = (fSlow3 + (0.999000013f * fRec2[1]));
			fVec0[(IOTA & 33554431)] = (fTemp0 * fRec2[0]);
			fRec0[(IOTA & 33554431)] = (((1.0f - fRec1[0]) * fRec0[((IOTA - iSlow2) & 33554431)]) + fVec0[((IOTA - iSlow4) & 33554431)]);
			float fTemp1 = fRec0[((IOTA - 0) & 33554431)];
			fRec3[0] = (fSlow5 + (0.999000013f * fRec3[1]));
			float fTemp2 = (fRec3[0] + 1.0f);
			fRec5[0] = (fSlow6 + (0.999000013f * fRec5[1]));
			fRec6[0] = (fSlow9 + (0.999000013f * fRec6[1]));
			fVec1[(IOTA & 33554431)] = (fTemp0 * fRec6[0]);
			fRec4[(IOTA & 33554431)] = (((1.0f - fRec5[0]) * fRec4[((IOTA - iSlow8) & 33554431)]) + fVec1[((IOTA - iSlow10) & 33554431)]);
			float fTemp3 = fRec4[((IOTA - 0) & 33554431)];
			fRec7[0] = (fSlow11 + (0.999000013f * fRec7[1]));
			float fTemp4 = (fRec7[0] + 1.0f);
			fRec9[0] = (fSlow12 + (0.999000013f * fRec9[1]));
			fRec10[0] = (fSlow15 + (0.999000013f * fRec10[1]));
			fVec2[(IOTA & 33554431)] = (fTemp0 * fRec10[0]);
			fRec8[(IOTA & 33554431)] = (((1.0f - fRec9[0]) * fRec8[((IOTA - iSlow14) & 33554431)]) + fVec2[((IOTA - iSlow16) & 33554431)]);
			float fTemp5 = fRec8[((IOTA - 0) & 33554431)];
			fRec11[0] = (fSlow17 + (0.999000013f * fRec11[1]));
			float fTemp6 = (fRec11[0] + 1.0f);
			fRec13[0] = (fSlow18 + (0.999000013f * fRec13[1]));
			fRec14[0] = (fSlow21 + (0.999000013f * fRec14[1]));
			fVec3[(IOTA & 33554431)] = (fTemp0 * fRec14[0]);
			fRec12[(IOTA & 33554431)] = (((1.0f - fRec13[0]) * fRec12[((IOTA - iSlow20) & 33554431)]) + fVec3[((IOTA - iSlow22) & 33554431)]);
			float fTemp7 = fRec12[((IOTA - 0) & 33554431)];
			fRec15[0] = (fSlow23 + (0.999000013f * fRec15[1]));
			float fTemp8 = (fRec15[0] + 1.0f);
			fRec17[0] = (fSlow24 + (0.999000013f * fRec17[1]));
			fRec18[0] = (fSlow27 + (0.999000013f * fRec18[1]));
			fVec4[(IOTA & 33554431)] = (fTemp0 * fRec18[0]);
			fRec16[(IOTA & 33554431)] = (((1.0f - fRec17[0]) * fRec16[((IOTA - iSlow26) & 33554431)]) + fVec4[((IOTA - iSlow28) & 33554431)]);
			float fTemp9 = fRec16[((IOTA - 0) & 33554431)];
			fRec19[0] = (fSlow29 + (0.999000013f * fRec19[1]));
			float fTemp10 = (fRec19[0] + 1.0f);
			fRec21[0] = (fSlow30 + (0.999000013f * fRec21[1]));
			fRec22[0] = (fSlow33 + (0.999000013f * fRec22[1]));
			fVec5[(IOTA & 33554431)] = (fTemp0 * fRec22[0]);
			fRec20[(IOTA & 33554431)] = (((1.0f - fRec21[0]) * fRec20[((IOTA - iSlow32) & 33554431)]) + fVec5[((IOTA - iSlow34) & 33554431)]);
			float fTemp11 = fRec20[((IOTA - 0) & 33554431)];
			fRec23[0] = (fSlow35 + (0.999000013f * fRec23[1]));
			float fTemp12 = (fRec23[0] + 1.0f);
			fRec25[0] = (fSlow36 + (0.999000013f * fRec25[1]));
			fRec26[0] = (fSlow39 + (0.999000013f * fRec26[1]));
			fVec6[(IOTA & 33554431)] = (fTemp0 * fRec26[0]);
			fRec24[(IOTA & 33554431)] = (((1.0f - fRec25[0]) * fRec24[((IOTA - iSlow38) & 33554431)]) + fVec6[((IOTA - iSlow40) & 33554431)]);
			float fTemp13 = fRec24[((IOTA - 0) & 33554431)];
			fRec27[0] = (fSlow41 + (0.999000013f * fRec27[1]));
			float fTemp14 = (fRec27[0] + 1.0f);
			fRec29[0] = (fSlow42 + (0.999000013f * fRec29[1]));
			fRec30[0] = (fSlow45 + (0.999000013f * fRec30[1]));
			fVec7[(IOTA & 33554431)] = (fTemp0 * fRec30[0]);
			fRec28[(IOTA & 33554431)] = (((1.0f - fRec29[0]) * fRec28[((IOTA - iSlow44) & 33554431)]) + fVec7[((IOTA - iSlow46) & 33554431)]);
			float fTemp15 = fRec28[((IOTA - 0) & 33554431)];
			fRec31[0] = (fSlow47 + (0.999000013f * fRec31[1]));
			float fTemp16 = (fRec31[0] + 1.0f);
			output0[i] = FAUSTFLOAT(((fTemp1 * (1.0f - (0.5f * fTemp2))) + ((fTemp3 * (1.0f - (0.5f * fTemp4))) + ((fTemp5 * (1.0f - (0.5f * fTemp6))) + ((fTemp7 * (1.0f - (0.5f * fTemp8))) + ((fTemp9 * (1.0f - (0.5f * fTemp10))) + ((fTemp11 * (1.0f - (0.5f * fTemp12))) + ((fTemp13 * (1.0f - (0.5f * fTemp14))) + (fTemp15 * (1.0f - (0.5f * fTemp16)))))))))));
			output1[i] = FAUSTFLOAT((0.5f * ((((((((fTemp1 * fTemp2) + (fTemp3 * fTemp4)) + (fTemp5 * fTemp6)) + (fTemp7 * fTemp8)) + (fTemp9 * fTemp10)) + (fTemp11 * fTemp12)) + (fTemp15 * fTemp16)) + (fTemp13 * fTemp14))));
			fRec1[1] = fRec1[0];
			fRec2[1] = fRec2[0];
			IOTA = (IOTA + 1);
			fRec3[1] = fRec3[0];
			fRec5[1] = fRec5[0];
			fRec6[1] = fRec6[0];
			fRec7[1] = fRec7[0];
			fRec9[1] = fRec9[0];
			fRec10[1] = fRec10[0];
			fRec11[1] = fRec11[0];
			fRec13[1] = fRec13[0];
			fRec14[1] = fRec14[0];
			fRec15[1] = fRec15[0];
			fRec17[1] = fRec17[0];
			fRec18[1] = fRec18[0];
			fRec19[1] = fRec19[0];
			fRec21[1] = fRec21[0];
			fRec22[1] = fRec22[0];
			fRec23[1] = fRec23[0];
			fRec25[1] = fRec25[0];
			fRec26[1] = fRec26[0];
			fRec27[1] = fRec27[0];
			fRec29[1] = fRec29[0];
			fRec30[1] = fRec30[0];
			fRec31[1] = fRec31[0];
		}
	}

};

#endif
