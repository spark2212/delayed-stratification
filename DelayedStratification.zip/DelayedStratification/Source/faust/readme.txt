faust to juce with using faustMinimalInlined.h

Simple Instructions
1. Create a faust dsp project
2. Export your faust dsp project via source > cplusplus
3. The content of the downloaded C++ file can then be copied and pasted at the end of the faustMinimalInlined.h after the BEGIN-FAUSTDSP tags.
4. #Include the faustMinimalInlined.h file in the processor header of the plugin


Detailed instructions are available on the faust website
https://faustdoc.grame.fr/workshops/2020-04-10-faust-juce/
